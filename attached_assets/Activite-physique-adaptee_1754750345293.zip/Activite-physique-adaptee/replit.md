# Overview

CalmCare is a mental health and addiction recovery support application built as a Progressive Web App (PWA). The application provides users with therapeutic exercises, craving tracking, journaling capabilities, and progress monitoring to support their recovery journey. It features a mobile-first design with a comprehensive set of tools for managing addiction cravings and maintaining mental wellness.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React with TypeScript, using Wouter for client-side routing
- **UI Framework**: Shadcn/ui component library built on Radix UI primitives with Tailwind CSS for styling
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Mobile-First Design**: Responsive layout optimized for mobile devices with bottom navigation and mobile-specific components
- **Styling**: Tailwind CSS with custom CSS variables for theming, including therapeutic color schemes

## Backend Architecture
- **Runtime**: Node.js with Express.js as the web framework
- **API Design**: RESTful API with JSON responses
- **Development Setup**: Vite for frontend bundling and development server with HMR (Hot Module Replacement)
- **Build Process**: ESBuild for backend bundling, separate build processes for client and server

## Data Layer
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Schema Design**: Tables for users, cravings, exercises, exercise sessions, journal entries, and user settings
- **Database Management**: Drizzle Kit for migrations and schema management
- **Storage Interface**: Abstract storage interface (IStorage) allowing for future database implementations

## Key Features
- **Craving Tracking**: Intensity-based logging system (1-10 scale) with emotional context
- **Exercise System**: Categorized therapeutic exercises (breathing, physical, meditation, stretching) with difficulty levels
- **Emergency Support**: Special emergency exercises with SOS functionality for crisis situations
- **Progress Analytics**: Statistical tracking with daily activity charts and completion metrics
- **Journal System**: Free-form text entries with optional mood tracking
- **User Settings**: Customizable preferences and notification settings

## Authentication & User Management
- **Demo Mode**: Currently uses a default user ID for demonstration purposes
- **User Schema**: Prepared for full authentication with username/email structure
- **Session Management**: Infrastructure in place for session-based authentication

## Development Environment
- **TypeScript**: Full TypeScript support across client, server, and shared code
- **Path Aliases**: Configured path mapping for clean imports (@/, @shared/, @assets/)
- **Hot Reloading**: Development setup with Vite providing fast refresh and error overlay
- **Code Organization**: Monorepo structure with separated client, server, and shared directories

# External Dependencies

## Database & ORM
- **Drizzle ORM**: Type-safe database operations with PostgreSQL dialect
- **@neondatabase/serverless**: Serverless PostgreSQL connection for Neon database
- **connect-pg-simple**: PostgreSQL session store for Express sessions

## UI & Styling
- **Radix UI**: Comprehensive set of accessible UI primitives
- **Tailwind CSS**: Utility-first CSS framework with custom therapeutic color variables
- **Lucide React**: Icon library for consistent iconography
- **class-variance-authority**: Utility for managing component variants

## State Management & Data Fetching
- **TanStack React Query**: Server state management with caching and background updates
- **React Hook Form**: Form state management with validation
- **@hookform/resolvers**: Form validation resolvers

## Development Tools
- **Vite**: Frontend build tool and development server
- **@replit/vite-plugin-runtime-error-modal**: Replit-specific development enhancements
- **@replit/vite-plugin-cartographer**: Development tooling integration

## Utility Libraries
- **date-fns**: Date manipulation and formatting
- **clsx & tailwind-merge**: Conditional class name utilities
- **nanoid**: Unique ID generation
- **zod**: Runtime type validation and schema parsing
- **drizzle-zod**: Integration between Drizzle ORM and Zod validation